# Design System Document: The Focused Editorial

## 1. Overview & Creative North Star
**Creative North Star: The Digital Curator**
This design system rejects the cluttered, "utility-first" appearance of traditional task managers. Instead, it adopts an editorial approach—treating tasks not as data points, but as meaningful content. Inspired by the clarity of Notion and the efficiency of Todoist, this system prioritizes "Negative Space as Structure." 

We break the "template" look by utilizing intentional asymmetry in header placements, high-contrast typography scales that guide the eye, and a layered surface architecture. The goal is to create a workspace that feels like a premium stationery set: tactile, expensive, and deeply organized.

---

## 2. Colors: Tonal Architecture
We move away from flat UI by using a sophisticated palette of Indigo and neutral grays. 

### The Palette (Material Design Tokens)
- **Primary (The Signature):** `#3525CD` (Primary) / `#4F46E5` (Primary Container). Use the Container for active task states to provide "soul" without visual fatigue.
- **Surface & Background:** `#F8F9FA` (Surface). This is our base "paper."
- **Status Tones:** 
    - *Done:* Tertiary Fixed Dim (`#FFB695`) — used for a sophisticated "muted" success rather than a jarring neon green.
    - *In-Progress:* Primary Fixed (`#E2DFFF`).
    - *To-Do:* Surface Variant (`#E1E3E4`).

### The "No-Line" Rule
**Explicit Instruction:** Do not use 1px solid borders to section content. Boundaries must be defined strictly through background color shifts. A task list (Surface Container Low) should sit on the main Background (Surface) without a stroke.

### The "Glass & Gradient" Rule
To elevate the primary CTA (Add Task), use a subtle linear gradient from `primary` to `primary_container`. For floating navigation or modals, utilize Glassmorphism: `surface_container_lowest` at 80% opacity with a 16px backdrop blur.

---

## 3. Typography: Editorial Hierarchy
We use **Inter** not as a system font, but as a Swiss-style design tool. 

- **Display (The Statement):** `display-md` (2.75rem). Use for empty states or "Good Morning" greetings. Tighten letter spacing to -0.02em.
- **Headline (The Navigator):** `headline-sm` (1.5rem). Used for project titles. This should feel authoritative.
- **Title (The Task):** `title-md` (1.125rem). Medium weight (500). This is the focal point of every card.
- **Body (The Detail):** `body-md` (0.875rem). Use `on_surface_variant` (`#464555`) for task descriptions to maintain a clear hierarchy between title and meta-data.
- **Labels (The Metadata):** `label-sm` (0.6875rem). Uppercase with +0.05em tracking for tags and dates.

---

## 4. Elevation & Depth: Tonal Layering
Traditional drop shadows are banned unless an object is physically "floating" over other content.

- **The Layering Principle:** 
    - **Level 0 (Base):** `surface` (#F8F9FA).
    - **Level 1 (Sections):** `surface_container_low` (#F3F4F5).
    - **Level 2 (Cards):** `surface_container_lowest` (#FFFFFF).
    *By stacking White on Light Gray, we create a soft, natural lift.*

- **Ambient Shadows:** When a Modal or FAB (Floating Action Button) is required, use a shadow color tinted with the `primary` hue: `rgba(53, 37, 205, 0.06)` with a 32px blur and 12px Y-offset.
- **The "Ghost Border" Fallback:** If accessibility requires a border, use `outline_variant` at 15% opacity. It should be felt, not seen.

---

## 5. Components: Minimal Primitives

### Cards & Lists
**Constraint:** No dividers. 
- Use `spacing-4` (1rem) of vertical white space to separate tasks. 
- Task cards use `md` (12px) roundedness.
- Active/Pressed state: Shift background to `surface_container_high`.

### Buttons
- **Primary:** Gradient-filled (`primary` to `primary_container`), `full` (pill) roundedness. No shadow.
- **Secondary:** `surface_container_highest` background with `on_surface` text.
- **Tertiary (Ghost):** No background. Text color is `primary`.

### Inputs
- **Text Fields:** Abandon the "box." Use a `surface_container_low` fill with a `none` border. On focus, transition the background to `surface_container_lowest` and add a 1pt "Ghost Border" in `primary`.

### Progress Indicators (Custom)
Instead of a standard bar, use a **Tonal Micro-Bar**: A thin 4px track using `surface_container_highest` with a `primary` fill, placed at the very top of a Project Card.

---

## 6. Do's and Don'ts

### Do
- **Do** use `spacing-8` (2rem) for page margins to create an "Editorial" feel.
- **Do** stagger the entry of list items with a 50ms staggered fade-in animation.
- **Do** use `on_surface_variant` for secondary information to reduce visual noise.

### Don't
- **Don't** use pure black (#000000). Always use `on_surface` (#191C1D).
- **Don't** use standard Material icons. Use light-weight (2pt stroke) out-lined icons to match the Inter typeface weight.
- **Don't** crowd the screen. If a screen has more than 7 primary actions, use a "More" menu to preserve the minimal aesthetic.

---

## 7. Spacing & Geometry
- **Grid:** 8px baseline. 
- **Radius:** `md` (12px) for cards/modals. `full` for buttons and tags.
- **Touch Targets:** Minimum 44x44dp, regardless of the visual size of the icon/label.